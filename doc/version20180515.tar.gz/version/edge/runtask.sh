#!/bin/bash
while true
do
wget http://127.0.0.1:8965/runtask -O /dev/null -o /dev/null
sleep 1
done
