#!/bin/bash
dir=$(pwd)
runpath=$dir/run/source-center
webpath="/data"
domain="*.*"
#flag_run_path_str
#flag_domain_str
#flag_web_path_str

function mykill()
{
while :
do
        killPid=`ps -ef |grep "$1" |grep -v grep | awk '{print $2}'`
        if [ "$killPid" != "" ]; then
        killall -9 $1
        kill -9 $killPid
        sleep 1
        else
        break
        fi
done
}
mykill "$dir/nginx-video/bin/nginx/sbin/nginx"
mkdir -p cd /usr/local/bin/m1905/

rm -f /lib64/libcdnbase.so
cp $dir/../base/libcdnbase.so /lib64
chmod +x /lib64/libcdnbase.so

/sbin/iptables -I INPUT -p tcp --dport 8087 -j ACCEPT

cd /usr/local/bin/m1905/
echo "save redis"
/usr/local/bin/m1905/redis-cli -p 8960 save
#kill����redis
mykill "/usr/local/bin/m1905/redis-server"
cd $dir/../base
rm -rf redis-2.6.14
tar  -xf  redis-2.6.14.lei.bin.tar.gz
cd redis-2.6.14
if [ ! -f "/usr/local/bin/m1905/redis-server" ]; then
#make
#make install
mkdir -p /usr/local/bin/m1905
cp bin/* /usr/local/bin/m1905/
chmod +x /usr/local/bin/m1905/*
fi
rm -f /usr/local/bin/m1905/redis.conf
cp  redis.conf  /usr/local/bin/m1905/
cd ..
rm -rf redis-2.6.14
echo "start redis!"
cd /usr/local/bin/m1905/
nohup /usr/local/bin/m1905/redis-server  /usr/local/bin/m1905/redis.conf &
cd $dir
sleep 2

cd $dir
mykill "$dir/nginx-video/bin/nginx/sbin/nginx"
rm -rf $dir/nginx-video/bin
cp -r $dir/../base/nginx-video/bin $dir/nginx-video
rm -rf $runpath/data/conf
mkdir -p $runpath
cp -r nginx-video/conf/cache/conf $runpath

#***********************************
cd $runpath/conf
flagstr="flag_run_path_str"
dststr=$dir/run/source-center
sed -i s#$flagstr#$dststr#g `grep $flagstr -rl ./`

flagstr="flag_domain_str"
dststr=$domain
sed -i s#$flagstr#$dststr#g `grep $flagstr -rl ./`

flagstr="flag_web_path_str"
dststr=$webpath
sed -i s#$flagstr#$dststr#g `grep $flagstr -rl ./`
#***********************************

cd $dir
chmod +x $dir/nginx-video/bin/nginx/sbin/*
sleep 1
rm -f run.sh
mkdir -p $runpath/data
mkdir -p $runpath/data/logs
mkdir -p $runpath/data/rtmp.socket
echo "$dir/nginx-video/bin/nginx/sbin/nginx -p $runpath/data -c $runpath/conf/nginx.conf">>run.sh
sh run.sh
sleep 1
ps -ef|grep nginx
rm -f run.sh

