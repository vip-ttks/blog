#!/bin/bash
dir=$(pwd)
videoDiskSet="/data1/www|/data2/www"
cacheDiskSet="/data3/www"
domainDiaoDu="diaodudemo.forcetechcloud.com:1234"
domainMsgCenter="jinan.msgcenter.forcetech.net"
curnodePort="38080"

#videoDiskSet �����洢��Ƶ�ļ� ���Ŀ¼������|�ָ� ���ǲ�����/��β
#cacheDiskSet ֻ����дһ��Ŀ¼�����洢����Ƶ���ļ� ������/��β
#domainDiaoDu���Զ����|�ָ� ������д�˿ںţ��˿ںű�����1234
#domainMsgCenterֻ����һ������ ���Ҳ����ж˿ںţ�������IP
#curnodePort="80"��ǰ�ڵ�ʹ�õĶ˿�

#flag_video_diskset_str
#flag_cache_diskset_str
#flag_domain_diaodu_str
#flag_domain_msgcenter_str
#flag_curnodePort_str

videoRootPath=$dir/video_root
#flag_video_root_path
mkdir -p /ftds2cdn
mkdir -p $videoRootPath
mkdir -p $cacheDiskSet
rm -f $dir/nohup.out
nohup killall -V
if  grep -q COPYING $dir/nohup.out ; then
        echo "have killall"
else
        echo "-------------no killall cmd-------------";
        exit
fi
rm -f $dir/nohup.out
function mykill()
{
while :
do
        killPid=`ps -ef |grep "$1" |grep -v grep | awk '{print $2}'`
        if [ "$killPid" != "" ]; then
        killall -9 $1
        kill -9 $killPid
        sleep 1
        else
        break
        fi
done
}

mykill "runtask.sh"
mykill "wget"
#kill����/usr/local/nginx/sbin/nginx
kill -QUIT `cat /usr/local/nginx-video/logs/nginx.pid`
mykill "/usr/local/nginx-video/sbin/nginx"
mykill "nginx: worker process is shutting down"
mykill "diaodu_c"

/sbin/iptables -I INPUT -p tcp --dport 8965 -j ACCEPT
/sbin/iptables -I INPUT -p tcp --dport 80 -j ACCEPT
rm -f /lib64/libcdnbase.so
cp $dir/../base/libcdnbase.so /lib64
chmod +x /lib64/libcdnbase.so

if [ ! -f "$dir/forcedown/forcelivetransfer.auth" ]; then
  echo "----------------------------------------------"
  echo "$dir/forcedown/forcelivetransfer.auth not exist"
  echo "use $dir/forcedown/force_linux.key to get auth"
  echo "----------------------------------------------"
  cd $dir/forcedown
  chmod +x transferclient
  ./transferclient
  exit
fi
rm -f /usr/local/bin/forceudp/forcelivetransfer.auth
rm -f /usr/local/bin/forceudp/transferclient
rm -f /usr/local/bin/forceudp/transferclient.conf
mkdir -p /usr/local/bin/forceudp
cp $dir/forcedown/forcelivetransfer.auth /usr/local/bin/forceudp
cp $dir/forcedown/transferclient /usr/local/bin/forceudp
cp $dir/forcedown/transferclient.conf /usr/local/bin/forceudp
chmod +x /usr/local/bin/forceudp/transferclient

mkdir -p /usr/local/bin/m1905/
cd /usr/local/bin/m1905/
echo "save redis"
/usr/local/bin/m1905/redis-cli -p 8960 save
#kill����redis
mykill "/usr/local/bin/m1905/redis-server"
cd $dir/../base
rm -rf redis-2.6.14
tar  -xf  redis-2.6.14.lei.bin.tar.gz
cd redis-2.6.14
if [ ! -f "/usr/local/bin/m1905/redis-server" ]; then
#make
#make install
mkdir -p /usr/local/bin/m1905
cp bin/* /usr/local/bin/m1905/
chmod +x /usr/local/bin/m1905/*
fi
rm -f /usr/local/bin/m1905/redis.conf
cp  redis.conf  /usr/local/bin/m1905/
cd ..
rm -rf redis-2.6.14
echo "start redis!"
cd /usr/local/bin/m1905/
echo "run /usr/local/bin/m1905/redis-server"
nohup /usr/local/bin/m1905/redis-server  /usr/local/bin/m1905/redis.conf &

cd $dir
rm -rf /usr/local/nginx-video/sbin
rm -rf /usr/local/nginx-video/html
mkdir -p /usr/local/nginx-video
cp -r $dir/../base/nginx-video/bin/nginx/* /usr/local/nginx-video
cp $dir/runtask.sh /usr/local/nginx-video/sbin/
chmod +x /usr/local/nginx-video/sbin/*
rm -rf /usr/local/nginx-video/conf
cp -r $dir/nginx-video/conf/cache/conf /usr/local/nginx-video
rm -rf /usr/local/nginx-video/html/demo.jpg

cd $dir
chmod +x /usr/local/nginx-video/sbin/*
mkdir -p /usr/local/nginx-video/logs
mkdir -p /usr/local/nginx-video/rtmp.socket
mkdir -p /usr/local/nginx-video/app
mkdir -p /usr/local/nginx-video/record

#�滻�㲥��Ƶ����·��
cd /usr/local/nginx-video/conf
flagstr="flag_video_diskset_str"
dststr=$videoDiskSet
sed -i s#$flagstr#$dststr#g `grep $flagstr -rl ./`
flagstr="flag_domain_msgcenter_str"
dststr=$domainMsgCenter
sed -i s#$flagstr#$dststr#g `grep $flagstr -rl ./`
flagstr="flag_cache_diskset_str"
dststr=$cacheDiskSet
sed -i s#$flagstr#$dststr#g `grep $flagstr -rl ./`
flagstr="flag_video_root_path"
dststr=$videoRootPath
sed -i s#$flagstr#$dststr#g `grep $flagstr -rl ./`
flagstr="flag_curnodePort_str"
dststr=$curnodePort
sed -i s#$flagstr#$dststr#g `grep $flagstr -rl ./`
echo "run /usr/local/nginx-video/sbin/nginx"
/usr/local/nginx-video/sbin/nginx -p /usr/local/nginx-video -c /usr/local/nginx-video/conf/nginx.conf

cd /usr/local/nginx-video/sbin
nohup sh /usr/local/nginx-video/sbin/runtask.sh &
nohup sh /usr/local/nginx-video/sbin/runtask.sh &
nohup sh /usr/local/nginx-video/sbin/runtask.sh &
nohup sh /usr/local/nginx-video/sbin/runtask.sh &
nohup sh /usr/local/nginx-video/sbin/runtask.sh &

cd $dir
rm -rf /data/cache/
mkdir -p /data/cache
cp diaodu_c/* /data/cache
cd /data/cache
flagstr="flag_domain_diaodu_str"
dststr=$domainDiaoDu
sed -i s#$flagstr#$dststr#g `grep $flagstr -rl ./`
chmod +x ./*
nohup ./diaodu_c -c config.ini &

cd $dir
mykill "forcedown"
mykill "transferclient"
chmod +x forcedown/*
rm -f /usr/local/bin/forcedown
rm -f /usr/local/bin/transferclient
cp forcedown/forcedown /usr/local/bin/
cp forcedown/transferclient /usr/local/bin/

cd $dir
sleep 1
ps -ef|grep nginx
ps -ef|grep diaodu_c
