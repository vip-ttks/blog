cd /data/cache
screen -d -m ./diaodu_c -c config.ini
