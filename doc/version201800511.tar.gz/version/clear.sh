#!/bin/bash
function mykill()
{
while :
do
        killPid=`ps -ef |grep "$1" |grep -v grep | awk '{print $2}'`
        if [ "$killPid" != "" ]; then
        killall -9 $1
        kill -9 $killPid
        sleep 1
        else
        break
        fi
done
}
pkill nginx
mykill "runtask.sh"
mykill "diaodu_c"
mykill "transferclient"
mykill "/usr/local/bin/m1905/redis-server"
rm -rf /usr/local/bin/m1905/
rm -rf /usr/local/bin/forceudp
ps -ef|grep nginx
